# Ryan Fernandez — Updated Portfolio Website

## Included
- `index.html` — responsive portfolio website
- `style.css` — styling
- `assets/ai-skincare-story-sample.mp4` — existing combined skincare/story sample
- `assets/2d-vector-animation-sample.mp4` — existing 2D vector animation sample

## Preview locally
Open `index.html` in a browser. Keep the `assets` folder beside it so videos play.

## Deploy to Vercel
1. Extract this ZIP.
2. In your GitHub portfolio repository, replace the old site files with the contents of this folder. Make sure `index.html` is at the repository root and upload the `assets` folder too.
3. Commit the changes to the branch connected to Vercel. Vercel should redeploy automatically.
4. Check the live URL after deployment. This package does not itself change your existing live website.

## Before applying to jobs
- Replace or supplement the two sample projects with your strongest finished work.
- Only label work as client work if it was genuinely commissioned by a client.
- Add a third real video file if you want three video projects displayed.
- Verify your contact information before publishing.
